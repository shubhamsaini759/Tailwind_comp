export const Scrolllist =[
    {
        name : 'trending'
    },
    {
        name : 'horror'
    },
    {
        name : 'top rated'
    },
    {
        name : 'action'
    },
    {
        name : 'comedy'
    },
    {
        name : 'romance'
    },
    {
        name : 'sci-fi'
    }
]