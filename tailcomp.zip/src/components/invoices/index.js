import React from 'react'

const Invoices = () => {
  return (
    <div>

        
    </div>
  )
}

export default Invoices