// Navbar
    // app.js
            {/* <div className="w-auto lg:flex justify-center ">
                <Header />
                </div> */}
    
    // navbar.js
            // import React, { useState } from 'react'
            // import { Button, Drawer } from 'antd';
            // import { FaBars } from "react-icons/fa";
            // const Header = () => {
            //     const [open, setOpen] = useState(false);
            //     const showDrawer = () => {
            //     setOpen(true);
            //     };
            //     const onClose = () => {
            //     setOpen(false);
            //     };
            // return (
            //     <div className='h-16 px-4 w-auto shadow-md flex justify-between items-center lg:w-2/3  ' >
            //         <p className='text-xl  font-bold ' >Hello World</p>
            //         <FaBars className=' lg:hidden' onClick={showDrawer} />
            //         <Drawer title="Basic Drawer" placement="right" onClose={onClose} open={open}>
            //             <p className='text-lg font-semibold' onClick={onClose} >Home</p>
            //             <p className='text-lg font-semibold' onClick={onClose} >About</p>
            //             <p className='text-lg font-semibold' onClick={onClose} >Products</p>
            //             <p className='text-lg font-semibold' onClick={onClose} >Contact</p>
            //         </Drawer>
            //         <div className='hidden lg:inline-flex gap-5 ' >
            //             <p className='text-lg font-semibold'  >Home</p>
            //             <p className='text-lg font-semibold'  >About</p>
            //             <p className='text-lg font-semibold'  >Products</p>
            //             <p className='text-lg font-semibold'  >Contact</p>
            //         </div>
            //     </div>
            // )
            // }
            // export default Header